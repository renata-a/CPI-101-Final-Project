# CPI-101-Final-Project
For our Milestone 2 we have laid out our Webpage which will be used as a new Space for students to interact with eachother, discover and share !
